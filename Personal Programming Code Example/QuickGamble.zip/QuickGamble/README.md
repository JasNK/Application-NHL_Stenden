# QuickGamble
De "QuickGamble" app is dé manier om snel en gemakkelijk weddenschappen aan te gaan met vrienden. Met deze app kun je het kaartenspel “” spelen.
